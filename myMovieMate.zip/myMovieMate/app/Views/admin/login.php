<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="content-type" content="text/html;charset=utf-8" />
    <title>Login | My Movie Mate</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="" name="keywords">
    <meta content="" name="description">

    <!-- Favicon -->
    <link href="<?php echo base_url(); ?>/assets/img/favicon.png" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com/">
    <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;family=Roboto:wght@500;700&amp;display=swap" rel="stylesheet"> 
    
    <!-- Icon Font Stylesheet -->
    <link href="<?php echo base_url(); ?>/assets/cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/assets/cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="<?php echo base_url(); ?>/assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="<?php echo base_url(); ?>/assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/cute-alert.css">

    <!-- Template Stylesheet -->
    <link href="<?php echo base_url(); ?>/assets/css/style.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid position-relative d-flex p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->


        <!-- Sign In Start -->
        <div class="container-fluid">
            <div class="row h-100 align-items-center justify-content-center" style="min-height: 100vh;">
                <div class="col-12 col-sm-10 col-md-8 col-lg-6 col-xl-5">
                    <form id="loginForm" method="POST">
                        <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3">
                            <div class="text-center mb-3">
                                <img src="<?php echo base_url(); ?>/assets/img/mini-logo.png" style="width: 150px;">
                            </div>
                            <div class="text-center mb-3">                            
                                <h3>Login</h3>
                            </div>
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com">
                                <label for="email">Email address</label>
                            </div>
                            <div class="row ms-1 mx-1">
                                <div class="col-10 form-floating mb-4 p-0">
                                    <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                                    <label for="password">Password</label>
                                </div>
                                <div class="col-2 mb-4 p-0">
                                    <button type="button" class="btn btn-warning py-3 w-100 mb-4" onclick="togglePassword();">
                                        <i class="fa fa-eye" id="eye"></i>
                                    </button>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary py-3 w-100 mb-4 formbtn">Login</button>
                            <p class="text-center mb-0">Don't have an Account? <a href="<?php echo base_url(); ?>/register">Register</a></p>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <!-- Sign In End -->
    </div>

    <!-- JavaScript Libraries -->
    <script src="<?php echo base_url(); ?>/assets/code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/chart/chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/easing/easing.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/cute-alert.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
</body>
</html>

<script type="text/javascript">    
    function togglePassword() {
        $("#eye").toggleClass("fa-eye fa-eye-slash");
        input = $("#password");
        if (input.attr("type") == "password") {
          input.attr("type", "text");
        } else {
          input.attr("type", "password");
        }
    }

    $("#loginForm").validate({
        rules: {
          email: "required",
          password: "required"
        },
        messages: {
          email: "Please Enter Email. This field is required.",
          password: "Please Enter Password. This field is required."
        },
        errorPlacement: function (error, element) {
          error.insertBefore(element.parent());
        },
        submitHandler: function () {
            $('.formbtn').prop('disabled', true);

            $.ajax({
                url: '<?php echo base_url(); ?>/api/ajaxLogin',
                type: 'post',
                data: $('#loginForm').serialize(),
                dataType: 'json',
                success: function (data) {
                    cuteToast({
                        title: data.title,
                        type: data.status,
                        message: data.message,
                        timer: 1500
                    });

                    if (data.status == 'success') {
                        setTimeout(function () {
                            window.location.reload();
                        },1600);
                    }
                    
                    $('.formbtn').prop('disabled', false);
                },            
                error: function (data) {
                    window.location.reload();
                    $('.formbtn').prop('disabled', false);
                }
            });
            return false;
        }        
    });
</script>