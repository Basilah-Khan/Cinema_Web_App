<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="content-type" content="text/html;charset=utf-8" />
        <title>My Movie Mate</title>
        <meta content="width=device-width, initial-scale=1.0" name="viewport">
        <meta content="" name="keywords">
        <meta content="" name="description">

        <!-- Favicon -->
        <link href="<?php echo base_url(); ?>/assets/img/favicon.png" rel="icon">

        <!-- Google Web Fonts -->
        <link rel="preconnect" href="https://fonts.googleapis.com/">
        <link rel="preconnect" href="https://fonts.gstatic.com/" crossorigin>
        <link href="https://fonts.googleapis.com/css2?family=Open+Sans:wght@400;600&amp;family=Roboto:wght@500;700&amp;display=swap" rel="stylesheet"> 
          
        <!-- Icon Font Stylesheet -->
        <link href="<?php echo base_url(); ?>/assets/cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
        <link href="<?php echo base_url(); ?>/assets/cdn.jsdelivr.net/npm/bootstrap-icons%401.4.1/font/bootstrap-icons.css" rel="stylesheet">

        <!-- Libraries Stylesheet -->
        <link href="<?php echo base_url(); ?>/assets/lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
          <link href="<?php echo base_url(); ?>/assets/lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

        <!-- Customized Bootstrap Stylesheet -->
        <link href="<?php echo base_url(); ?>/assets/css/bootstrap.min.css" rel="stylesheet">
        <link rel="stylesheet" href="<?php echo base_url(); ?>/assets/css/cute-alert.css">

        <!-- Template Stylesheet -->
        <link href="<?php echo base_url(); ?>/assets/css/style.css" rel="stylesheet">
    </head>
    <?php if ($session['user_role'] == 'user'){ ?>
    <style type="text/css">
        .content {
            width: 100%;
            margin-left: 0;
        }
    <?php } ?>
    </style>
    <body>
        <div class="container-fluid position-relative d-flex p-0">
            <!-- Spinner Start -->
            <div id="spinner" class="show bg-dark position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
                <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                    <span class="sr-only">Loading...</span>
                </div>
            </div>
            <!-- Spinner End -->


            <!-- Sidebar Start -->
            <?php if ($session['user_role'] != 'user'){ ?>
            <div class="sidebar pe-4 pb-3">
                <nav class="navbar bg-secondary navbar-dark">
                    <a href="<?php echo base_url(); ?>" class="navbar-brand mx-4 mb-3">
                        <h3 class="text-dark">.</h3>
                    </a>
                    <div class="navbar-nav w-100">
                      <?php if ($session['user_role'] != 'admin'){ ?>
                        <a href="<?php echo base_url(); ?>" class="nav-item nav-link active"><i class="fa fa-tachometer-alt me-2"></i>Dashboard</a>
                        <div class="nav-item dropdown">
                          <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-user me-2"></i>User</a>
                          <div class="dropdown-menu bg-transparent border-0">
                              <a href="<?php echo base_url(); ?>/user/add_edit" class="dropdown-item">Add</a>
                              <a href="<?php echo base_url(); ?>/user/list" class="dropdown-item">List</a>
                          </div>
                        </div>
                      <?php } ?>
                        <div class="nav-item dropdown">
                          <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown"><i class="fa fa-video me-2"></i>Movies</a>
                          <div class="dropdown-menu bg-transparent border-0">
                              <a href="<?php echo base_url(); ?>/movie/add_edit" class="dropdown-item">Add</a>
                              <a href="<?php echo base_url(); ?>/movie/list" class="dropdown-item">List</a>
                          </div>
                        </div>
                        <a href="<?php echo base_url(); ?>/api/api_page" class="nav-item nav-link"><i class="far fa-file-alt me-2"></i>API</a>
                    </div>
                </nav>
            </div>
            <?php } ?>
            <!-- Sidebar End -->


            <!-- Content Start -->
            <div class="content">
                <!-- Navbar Start -->
                <nav class="navbar navbar-expand bg-secondary navbar-dark sticky-top px-4 py-0">
                    <?php if ($session['user_role'] != 'user'){ ?>
                        <a href="#" class="sidebar-toggler flex-shrink-0 mx-3">
                            <i class="fa fa-bars"></i>
                        </a>
                    <?php } ?>
                    <div class="logo-div">
                        <img src="<?php echo base_url(); ?>/assets/img/logo.png" style="height:50px;">
                    </div>
                    <div class="navbar-nav align-items-center ms-auto">
                        <div class="nav-item dropdown" title="<?php echo $session['user_name']; ?>">
                            <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                                <span><i class="fa fa-user"></i></span>
                                <span class="d-none d-lg-inline-flex"><?php echo $session['user_name']; ?></span>
                            </a>
                            <div class="dropdown-menu dropdown-menu-end bg-secondary border-0 rounded-0 rounded-bottom m-0">
                                <a href="<?php echo base_url(); ?>/logout" class="dropdown-item">Log Out</a>
                            </div>
                        </div>
                    </div>
                </nav>
                <!-- Navbar End -->