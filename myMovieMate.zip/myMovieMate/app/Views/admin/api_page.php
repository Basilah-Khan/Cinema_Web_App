<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">       
            <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                <h3> API - <a href="<?php echo base_url('/api/v1'); ?>">Link</a></h3>
            </div>

            <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3 mb-100">
                <div id="code">
                    <code>
                        <p><?php echo 'Link: '.base_url('/api/v1'); ?></p>
                        <pre id="json"></pre>
                    </code>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo view('admin/footer');?> 

<script type="text/javascript">   
    var data = <?php echo json_encode($apiData); ?>;
    document.getElementById("json").textContent = JSON.stringify(data, undefined, 2);
</script>