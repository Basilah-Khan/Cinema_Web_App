<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">
            <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                <h3>Users List</h3>
            </div>

            <div class="bg-secondary rounded p-3 my-4 mx-3 mb-100">  
                <table class="table" id="basic-datatable">
                    <thead>
                        <tr>
                            <th>Sr. No</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Role</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php 
                            foreach ($userList as $value) {
                                echo '<tr>'.
                                        '<td>'.$value['srno'].'</td>'.
                                        '<td>'.$value['name'].'</td>'.
                                        '<td>'.$value['email'].'</td>'.
                                        '<td>'.$value['role'].'</td>'.
                                        '<td>'.$value['action'].'</td>'.
                                      '</tr>';
                            }
                        ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>


<?php echo view('admin/footer'); ?>
