<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">       
            <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                <h3>
                    <?php if ($userData) { echo 'Edit User'; }else{ echo 'Add User'; } ?>  
                </h3>
            </div>

        	<form id="userForm" method="POST">
                <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3 mb-100">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control" id="username" name="username" placeholder="Jhon Doe" value="<?php if ($userData) { echo $userData['name']; } ?>">
                                <label for="username">Full Name</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" value="<?php if ($userData) { echo $userData['email']; } ?>">
                                <label for="email">Email address</label>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row ms-1 mx-1">
                            <div class="col-10 form-floating mb-4 p-0">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php if ($userData) { echo $userData['password']; } ?>">
                                <label for="password">Password</label>
                            </div>
                            <div class="col-2 mb-4 p-0">
                                <button type="button" class="btn btn-warning py-3 w-100 mb-4 formbtn" onclick="togglePassword();">
                                    <i class="fa fa-eye" id="eye"></i>
                                </button>
                            </div>
                        </div>  
                        <input type="hidden" name="id" value="<?php if ($userData) { echo $userData['id']; } ?>">                      
                    </div>
                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-3">                            
                            <button type="reset" class="btn btn-warning py-3 w-100 mb-4">Reset</button>
                        </div>
                        <div class="col-sm-3">
                            <button type="submit" class="btn btn-primary py-3 w-100 mb-4">Save</button>
                        </div>
                        <div class="col-sm-3"></div>
                    </div>
                </div>
            </form>
    	</div>
	</div>
</div>

<?php echo view('admin/footer');?> 

<script type="text/javascript">    
    function togglePassword() {
        $("#eye").toggleClass("fa-eye fa-eye-slash");
        input = $("#password");
        if (input.attr("type") == "password") {
          input.attr("type", "text");
        } else {
          input.attr("type", "password");
        }
    }

    $("#userForm").validate({
        rules: {
          username: "required",
          email: "required",
          password: "required"
        },
        messages: {
          username: "Please Enter Name. This field is required.",
          email: "Please Enter Email. This field is required.",
          password: "Please Enter Password. This field is required."
        },
        errorPlacement: function (error, element) {
          error.insertBefore(element.parent());
        },
        submitHandler: function () {
            $('.formbtn').prop('disabled', true);

            $.ajax({
                url: "<?php if ($userData) { echo base_url('/api/ajaxEditUser'); }else{ echo base_url('/api/ajaxAddUser'); } ?>",
                type: 'post',
                data: $('#userForm').serialize(),
                dataType: 'json',
                success: function (data) {
                    cuteToast({
                        title: data.title,
                        type: data.status,
                        message: data.message,
                        timer: 2000
                    });

                    if (data.status == 'success') {
                        setTimeout(function () {
                            window.location.href = "<?php echo base_url('user/list'); ?>";
                        },2100);
                    }

                    $('.formbtn').prop('disabled', false);
                },            
                error: function (data) {
                    window.location.reload();
                    $('.formbtn').prop('disabled', false);
                }
            });
            return false;
        }        
    });
</script>