<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">   
            <?php if($movieData){ ?>    
                <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                    <h3>
                        <?php echo ucfirst($movieData['title']); ?>  
                    </h3>
                </div>

                <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3 mb-100">
                    <div class="row">
                        <div class="col-md-12 col-lg-9" style="height: fit-content;" id="wrap_video">
                            <video class="my_video" poster="<?php echo base_url().'/upload/image/' .$movieData['img']; ?>" controls>
                               <source src="<?php echo base_url().'/upload/video/' .$movieData['link']; ?>" type="video/mp4">
                            </video>
                        </div>

                        <div class="col-md-12 col-lg-3">
                            <p>
                                <i class="fa fa-star text-warning"></i>
                                <span class="text-white ms-2"><?php echo $movieData['rating']; ?> <span>
                            </p>
                            <p>
                                <i class="fa fa-clock text-info"></i>
                                <span class="text-white ms-2"><?php echo $movieData['runtime']; ?> <span>
                            </p>
                            <p class="mb-0">
                                <i class="fa fa-calendar-day text-success"></i>
                                <span class="text-white ms-2"><?php echo date('d M, Y', strtotime($movieData['pub_date'])); ?> <span>
                            </p>
                            <p class="mt-2">
                                <span id="description" class="textOverflow"><?php echo $movieData['description']; ?></span>
                                <span id="show_hide" class="text-info" style="cursor:pointer;">Read More</span>
                            </p>
                        </div>
                    </div>
                </div>
            <?php }else{ ?>    
                <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                    <h3>Something went wrong!</h3>
                </div>
            <?php } ?> 
    	</div>
	</div>
</div>

<?php echo view('admin/footer');?> 

<script type="text/javascript">
$(document).ready(function () {
    $("#show_hide").on("click", function () {
        $("#description").toggleClass("textOverflow showAllText");
        var txt = $("#description").hasClass('textOverflow') ? 'Read More' : 'Read Less';
        $("#show_hide").text(txt);
        // $(this).next('.description').slideToggle(200);
    });
}); 
</script>