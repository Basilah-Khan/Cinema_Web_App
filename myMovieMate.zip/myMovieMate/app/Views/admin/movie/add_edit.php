<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">       
            <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                <h3>
                    <?php if ($movieData) { echo 'Edit Movie Details'; }else{ echo 'Add Movie Details'; } ?>  
                </h3>
            </div>

        	<form id="movieForm" method="POST" enctype="multipart/form-data">
                <div class="bg-secondary rounded p-4 p-sm-5 my-4 mx-3 mb-100">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="date" class="form-control bg-white" id="pub_date" name="pub_date" placeholder="" value="<?php if ($movieData) { echo $movieData['pub_date']; } ?>">
                                <label for="pub_date">Publication Date</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control bg-white" id="title" name="title" placeholder="" value="<?php if ($movieData) { echo $movieData['title']; } ?>" maxlength="100">
                                <label for="title">Title</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="time" class="form-control bg-white" id="runtime" name="runtime" placeholder="" value="<?php if ($movieData) { echo $movieData['runtime']; } ?>">
                                <label for="runtime">Runtime</label>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-floating mb-3">
                                <input type="text" class="form-control bg-white" id="rating" name="rating" placeholder="" value="<?php if ($movieData) { echo $movieData['rating']; } ?>" maxlength="3">
                                <label for="rating">Rating</label>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="img">
                                    Upload Image
                                    <?php if($movieData){ ?>
                                    <a href="<?php echo base_url().'/upload/image/' .$movieData['img']; ?>">View Image</a>
                                    <?php } ?>
                                </label>
                                <input type="file" class="form-control bg-white" id="img" name="img" placeholder="" accept= "image/*">
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group mb-3">
                                <label for="video">
                                    Upload Video 
                                    <?php if($movieData){ ?>
                                    <a href="<?php echo base_url().'/upload/video/' .$movieData['link']; ?>">View Video</a>
                                    <?php } ?>
                                </label>
                                <input type="file" class="form-control bg-white" id="video" name="video" placeholder="" accept= "video/*">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-12">
                        <div class="form-floating mb-3">
                            <textarea class="form-control bg-white h-25" id="description" name="description" placeholder="Description" maxlength="800"><?php if ($movieData) { echo $movieData['description']; } ?></textarea>
                            <label for="description">Description</label>
                        </div>
                    </div>

                    <input type="hidden" name="id" value="<?php if ($movieData) { echo $movieData['id']; } ?>">      

                    <div class="row">
                        <div class="col-sm-3"></div>
                        <div class="col-sm-3">                            
                            <button type="reset" class="btn btn-warning py-3 w-100 mb-4">Reset</button>
                        </div>
                        <div class="col-sm-3">
                            <button type="submit" class="btn btn-primary py-3 w-100 mb-4">Save</button>
                        </div>
                        <div class="col-sm-3"></div>
                    </div>
                </div>
            </form>
    	</div>
	</div>
</div>

<?php echo view('admin/footer');?> 

<script type="text/javascript">
    <?php if ($movieData) { ?>
        $("#movieForm").validate({
            rules: {
              pub_date: "required",
              title: "required",
              runtime: "required",
              rating: "required",
              description: "required"
            },
            messages: {
              pub_date: "Please select publication date. This field is required.",
              title: "Please enter title. This field is required.",
              runtime: "Please select runtime. This field is required.",
              rating: "Please enter rating. This field is required.",
              description: "Please enter description. This field is required."
            },
            errorPlacement: function (error, element) {
              error.insertBefore(element.parent());
            },
            submitHandler: function () {
                $('.formbtn').prop('disabled', true);

                var formData = new FormData();
                var video    = $('#video')[0].files[0];
                formData.append('video',video);
                var img    = $('#img')[0].files[0];
                formData.append('img',img);

                var inputData = $("#movieForm").serializeArray();
                for(var i in inputData){
                  formData.append(inputData[i].name,inputData[i].value);
                }
                // console.log(formData);return false;

                $.ajax({
                    url: "<?php echo base_url('/api/ajaxEditMovie'); ?>",
                    type: 'post',
                    // data: $('#movieForm').serialize(),
                    data: formData,
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        cuteToast({
                            title: data.title,
                            type: data.status,
                            message: data.message,
                            timer: 2000
                        });

                        if (data.status == 'success') {
                            setTimeout(function () {
                                window.location.href = "<?php echo base_url('movie/list'); ?>";
                            },2100);
                        }

                        $('.formbtn').prop('disabled', false);
                    },            
                    error: function (data) {
                        window.location.reload();
                        $('.formbtn').prop('disabled', false);
                    }
                });
                return false;
            }        
        });
    <?php }else{ ?> 
        $("#movieForm").validate({
            rules: {
              pub_date: "required",
              title: "required",
              runtime: "required",
              rating: "required",
              img: "required",
              video: "required",
              description: "required"
            },
            messages: {
              pub_date: "Please select publication date. This field is required.",
              title: "Please enter title. This field is required.",
              runtime: "Please select runtime. This field is required.",
              rating: "Please enter rating. This field is required.",
              img: "Please upload image. This field is required.",
              video: "Please upload video. This field is required.",
              description: "Please enter description. This field is required."
            },
            errorPlacement: function (error, element) {
              error.insertBefore(element.parent());
            },
            submitHandler: function () {
                $('.formbtn').prop('disabled', true);

                var formData = new FormData();
                var video    = $('#video')[0].files[0];
                formData.append('video',video);
                var img    = $('#img')[0].files[0];
                formData.append('img',img);

                var inputData = $("#movieForm").serializeArray();
                for(var i in inputData){
                  formData.append(inputData[i].name,inputData[i].value);
                }

                $.ajax({
                    url: "<?php echo base_url('/api/ajaxAddMovie'); ?>",
                    type: 'post',
                    data: formData,
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        cuteToast({
                            title: data.title,
                            type: data.status,
                            message: data.message,
                            timer: 2000
                        });

                        if (data.status == 'success') {
                            setTimeout(function () {
                                window.location.href = "<?php echo base_url('movie/list'); ?>";
                            },2100);
                        }

                        $('.formbtn').prop('disabled', false);
                    },            
                    error: function (data) {
                        window.location.reload();
                        $('.formbtn').prop('disabled', false);
                    }
                });
                return false;
            }        
        });
    <?php } ?> 
</script>
