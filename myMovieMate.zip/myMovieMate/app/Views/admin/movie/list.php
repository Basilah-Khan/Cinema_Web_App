<?php echo view('admin/header'); ?>

<div class="container-fluid pt-4 px-4">
    <div class="row g-4">
        <div class="col-lg-12">
            <div class="bg-secondary rounded p-3 my-4 mx-3">                  
                <h3>Movie List</h3>
            </div>

            <div class="p-3 mb-100">
                <div class="row">  
                    <?php 
                        $edit = '';
                        foreach ($movieList as $value) {
                            if ($session['user_role'] != 'user') {                            
                                $edit = '<a class="btn btn-primary editBtn" href="'. base_url() . '/movie/add_edit/'. $value['id'] .'"> <i class="fa fa-pencil-alt"></i> </a>';
                            }
                            echo '<div class="col-md-4 pb-2 pt-2 position-relative">'.
                                    '<div class="bg-secondary rounded p-3 movieDiv" title="'. $value['title'] .'" onclick="palyThis('. $value['id'] .');">'.
                                    '<img class="rounded w-100 movie_img" src="'. base_url() . '/upload/image/' . $value['img'] .'"> '.
                                    '<h4 class="movie_title text-primary mt-3">'. ucfirst($value['title']) .'</h4>'.
                                    '<p class="text-white textOverflow">'. ucfirst($value['description']) .'</p>'.
                                    '<p>
                                        <i class="fa fa-star text-warning"></i>
                                        <span class="text-white ms-2">'. $value['rating'] .'<span>
                                    </p>'.
                                    '<p>
                                        <i class="fa fa-clock text-info"></i>
                                        <span class="text-white ms-2">'. $value['runtime'] .'<span>
                                    </p>'.
                                    '<p class="mb-0">
                                        <i class="fa fa-calendar-day text-success"></i>
                                        <span class="text-white ms-2">'. date('d M, Y', strtotime($value['pub_date'])) .'<span>
                                    </p>'
                                    .$edit.
                                 '</div></div>';
                        }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>


<?php echo view('admin/footer'); ?>

<script type="text/javascript">
    function palyThis(id) {
        window.location.href = "<?php echo base_url(); ?>/movie/view/"+id;
    }    
</script>