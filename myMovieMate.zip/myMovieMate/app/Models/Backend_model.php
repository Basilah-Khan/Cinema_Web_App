<?php
namespace App\Models;
use CodeIgniter\Model;

class Entry_model extends Model {

    protected $db;
 
    public function __construct() {
        parent::__construct();
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
        $this->request = \Config\Services::request(); 
        $this->encrypter = \Config\Services::encrypter(); 
    } 

    public function userRegister($name,$email,$password){ 
        $arrResponse = array();
        $query = $this->db->query("SELECT * FROM user WHERE email = '$email'");        
        if($query->getNumRows()>0){   
            $arrResponse['status']  = 'error';
            $arrResponse['title']   = 'Error';
            $arrResponse['message'] = 'User Exist';
        }else{
            $arrayData = array(
                "role" => 'user',  
                "name" => "$name",
                "email"    => "$email",
                "password" => bin2hex($this->encrypter->encrypt($password)),
            );
            
            $this->db->table('user')->insert($arrayData);
            // echo $this->db->getLastQuery();die();
            $affected_rows = $this->db->affectedRows();
            if($affected_rows>0){
                $arrResponse['status']  = 'success';
                $arrResponse['title']   = 'Success';
                $arrResponse['message'] = 'User registered successfully';
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'Error occured while registering user. Try again later.';
            }
        }
        return $arrResponse;
    }

    public function userLogin($email,$password){ 
        $arrResponse = array();
        $query = $this->db->query("SELECT * FROM user WHERE email = '$email'");        
        if($query->getNumRows()>0){           
            $userDetails = $query->getResultArray()[0];

            if($this->encrypter->decrypt(hex2bin($userDetails['password'])) == $password) {
                $sessionArray = array(
                    'user_id'   => $userDetails['id'],
                    'user_role' => $userDetails['role'],
                    'user_name' => $userDetails['name'],
                );
                $this->session->set('user_sesssion',$sessionArray);

                $arrResponse['status'] = 'success';
                $arrResponse['title'] = 'Success';
                $arrResponse['message'] = 'Login Successful';
            }else{
                $arrResponse['status'] = 'error';
                $arrResponse['title'] = 'Error';
                $arrResponse['message'] = 'Please enter currect password';
            }
        }else{
            $arrResponse['status'] = 'error';
            $arrResponse['title'] = 'Error';
            $arrResponse['message'] = 'Please enter correct email';
        }
        return $arrResponse;
    }

    public function getDashboardData(){ 
        $arrResponse = array();
        $query = $this->db->query("SELECT COUNT(id) as movies, (SELECT COUNT(id) FROM user WHERE role = 'admin' ) as adminUsers, (SELECT COUNT(id) FROM user WHERE role = 'user' ) as rUsers FROM movie");         
        if($query->getNumRows()>0){            
            $data = $query->getResultArray()[0];  

            $arrResponse['adminUsers'] = $data['adminUsers'];
            $arrResponse['rUsers']     = $data['rUsers'];
            $arrResponse['movies']     = $data['movies'];
        }else{
            $arrResponse['adminUsers'] = 0;
            $arrResponse['rUsers']     = 0;
            $arrResponse['movies']     = 0;
        }

        $arrResponse['session'] = $this->session->get('user_sesssion');
        
        return $arrResponse;
    }

    // User 
        public function addUserData($data){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] == 'superadmin') {
                $email = $data['email'];
                $query = $this->db->query("SELECT * FROM user WHERE email = '$email' ");        
                if($query->getNumRows()>0){   
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'User Exist';
                }else{
                    $arrayData = array(
                        "role"     => 'admin',  
                        "name"     => $data['username'],
                        "email"    => $data['email'],
                        "password" => bin2hex($this->encrypter->encrypt($data['password'])),
                    );
                    
                    $this->db->table('user')->insert($arrayData);
                    // echo $this->db->getLastQuery();die();
                    $affected_rows = $this->db->affectedRows();
                    if($affected_rows>0){
                        $arrResponse['status']  = 'success';
                        $arrResponse['title']   = 'Success';
                        $arrResponse['message'] = 'User added successfully';
                    }else{
                        $arrResponse['status']  = 'error';
                        $arrResponse['title']   = 'Error';
                        $arrResponse['message'] = 'Error occured while adding user. Try again later.';
                    }
                }
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'You are not allowed to edit user';
            }
            return $arrResponse;
        }

        public function getUserData($id){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] == 'superadmin') {
                $query = $this->db->query("SELECT * FROM user WHERE role = 'admin' AND id = $id ");         
                if($query->getNumRows()>0){            
                    $data = $query->getResultArray()[0];  
                    $data['password'] = $this->encrypter->decrypt(hex2bin($data['password']));
                    $arrResponse = $data;
                }else{
                    $arrResponse = [];
                }
            }
            return $arrResponse;
        }

        public function editUserData($data){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] == 'superadmin') {
                $arrayData = array(
                    "name"     => $data['username'],
                    "email"    => $data['email'],
                    "password" => bin2hex($this->encrypter->encrypt($data['password'])),
                );
                $builder = $this->db->table('user');
                $builder->where('id', $data['id']);
                $builder->where('role', 'admin');
                $builder->update($arrayData);
                $affected_rows = $this->db->affectedRows();
                if($affected_rows>0){
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'User edited successfully';
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while editing user. Try again later.';
                }
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'You are not allowed to edit user';
            }
            return $arrResponse;
        }

        public function getUserList(){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] == 'superadmin') {
                $query = $this->db->query("SELECT * FROM user WHERE role = 'admin' ORDER BY id DESC ");         
                if($query->getNumRows()>0){            
                    $data = $query->getResultArray();  
                    $arr = array(); $x=1;
                    foreach ($data as $value) {
                        $action = '<a href="'. base_url() .'/user/add_edit/' . $value['id'] .'" class="btn btn-primary"> Edit </a>';
                        $arr = array(
                            'srno'   => $x,
                            'name'   => ucfirst($value['name']),
                            'email'  => $value['email'],
                            'role'   => ucfirst($value['role']),
                            'action' => $action,
                        );
                        $x++;
                        array_push($arrResponse, $arr);
                    }
                }else{
                    $arrResponse = [];
                }
            }
            
            return $arrResponse;
        }
    // User 

    // Movie 
        public function addMovieData($data){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] != 'user') {
                $title = $data['title'];
                $query = $this->db->query("SELECT * FROM movie WHERE title = '$title' ");        
                if($query->getNumRows()>0){   
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Movie Exist';
                }else{
                    $generatedName = rand(11111,99999);
                    $imgData = $this->request->getFile('img');
                    $videoData = $this->request->getFile('video');
                    if ($imgData) {
                        $filename     = $imgData->getName();
                        $img = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                        $imgData->move(ROOTPATH . '/upload/image/', $img, true);
                    }else{
                        $img = '';
                    }

                    if ($videoData) {
                        $filename     = $videoData->getName();
                        $video = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                        $videoData->move(ROOTPATH . '/upload/video/', $video, true);
                    }else{
                        $video = '';
                    }

                    $arrayData = array( 
                        "pub_date"    => $data['pub_date'],
                        "title"       => $data['title'],
                        "runtime"     => date('H:i:s', strtotime($data['runtime'])),
                        "rating"      => $data['rating'],
                        "description" => $data['description'],
                        "img"         => $img,
                        "link"        => $video,
                    );
                    
                    $this->db->table('movie')->insert($arrayData);
                    $affected_rows = $this->db->affectedRows();
                    if($affected_rows>0){
                        $arrResponse['status']  = 'success';
                        $arrResponse['title']   = 'Success';
                        $arrResponse['message'] = 'Movie details added successfully';
                    }else{
                        $arrResponse['status']  = 'error';
                        $arrResponse['title']   = 'Error';
                        $arrResponse['message'] = 'Error occured while adding movie details. Try again later.';
                    }
                }
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'You are not allowed to add movie details';
            }
            return $arrResponse;
        }

        public function getMovieData($id){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
                $query = $this->db->query("SELECT * FROM movie WHERE id = $id ");         
                if($query->getNumRows()>0){            
                    $data = $query->getResultArray()[0];  
                    $arrResponse = $data;
                }else{
                    $arrResponse = [];
                }
            return $arrResponse;
        }

        public function editMovieData($data){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            if ($SESSION['user_role'] != 'user') {

                $arrayData = array( 
                    "pub_date"    => $data['pub_date'],
                    "title"       => $data['title'],
                    "runtime"     => date('H:i:s', strtotime($data['runtime'])),
                    "rating"      => $data['rating'],
                    "description" => $data['description'],
                );

                $generatedName = rand(11111,99999);
                $imgData = $this->request->getFile('img');
                $videoData = $this->request->getFile('video');

                if ($imgData) {
                    $filename     = $imgData->getName();
                    $img = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                    $imgData->move(ROOTPATH . '/upload/image/', $img, true);
                    $arrayData = $arrayData + array("img" => $img);
                }

                if ($videoData) {
                    $filename     = $videoData->getName();
                    $video = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                    $videoData->move(ROOTPATH . '/upload/video/', $video, true);
                    $arrayData = $arrayData + array("link" => $video);
                }

                $builder = $this->db->table('movie');
                $builder->where('id', $data['id']);
                $builder->update($arrayData);
                $affected_rows = $this->db->affectedRows();
                if($affected_rows>0){
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'Movie details edited successfully';
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while editing movie details. Try again later.';
                }
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'You are not allowed to edit movie details';
            }
            return $arrResponse;
        }

        public function getMovieList(){ 
            $SESSION = $this->session->get('user_sesssion');
            $arrResponse = array();
            $query = $this->db->query("SELECT * FROM movie");         
            if($query->getNumRows()>0){            
                $arrResponse = $query->getResultArray();                      
            }else{
                $arrResponse = [];
            }
            
            return $arrResponse;
        }
    // Movie 

    // Required Api/v1 
        public function getAllMovieData(){ 
            $arrResponse = array();
            $query = $this->db->query("SELECT * FROM movie ");    
            // echo $this->db->getLastQuery();die();     
            if($query->getNumRows()>0){            
                $arrResponse = $query->getResultArray(); 
            }else{
                $arrResponse = [];
            }
            return $arrResponse;
        }
    // Required Api/v1 
}

