<?php
namespace App\Controllers;

class Movie extends BaseController{

    public function list(){
        if ($this->session->has('user_sesssion')) {
            $data['session'] = $this->session->get('user_sesssion');
            $data['movieList'] = $this->Backend->getMovieList();
            
            return view('admin/movie/list',$data);
        }else{
            return redirect()->to(base_url());
        }
    }

    public function add_edit($movie_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session'] = $this->session->get('user_sesssion');
            
            if ($data['session']['user_role'] == 'user') {
                return redirect()->to(base_url('/movie/list'));
            }else{
                if($movie_id!=''){
                    $data['movieData'] = $this->Backend->getMovieData($movie_id);
                }else{
                    $data['movieData'] = [];
                }

                return view('admin/movie/add_edit',$data); 
            }           
        }else{
            return redirect()->to(base_url());
        }
    }

    public function view($movie_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session'] = $this->session->get('user_sesssion');
            if($movie_id!=''){
                $data['movieData'] = $this->Backend->getMovieData($movie_id);
            }else{
                $data['movieData'] = [];
            }

            return view('admin/movie/view',$data);                        
        }else{
            return redirect()->to(base_url());
        } 
    }
}