<?php
namespace App\Controllers;

class Api extends BaseController{
    public function ajaxRegister(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->userRegister($postData['username'],$postData['email'],$postData['password']);
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function ajaxLogin(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->userLogin($postData['email'],$postData['password']);          
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function ajaxAddUser(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->addUserData($postData);          
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function ajaxEditUser(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->editUserData($postData);          
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function ajaxAddMovie(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->addMovieData($postData);          
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function ajaxEditMovie(){
        header('Content-Type: application/json; charset=utf-8');
        $postData = $this->request->getPost();
        if($postData){
            $result = $this->Backend->editMovieData($postData);          
          
            $arrayResponse['status']  = $result['status'];
            $arrayResponse['title']   = $result['title'];
            $arrayResponse['message'] = $result['message'];        
        }else{
            $arrayResponse['status']  = 'error';
            $arrayResponse['title']   = 'Error';
            $arrayResponse['message'] = 'Non-Authoritative Information';
        }
        echo json_encode($arrayResponse);
    }

    public function api_page(){
        if ($this->session->has('user_sesssion')) {  
            $data['apiData'] = $this->Backend->getAllMovieData();
            $data['session'] = $this->session->get('user_sesssion');
            return view('admin/api_page',$data);                        
        }else{
            return redirect()->to(base_url());
        }
    }

    public function v1(){
        header('Content-Type: application/json; charset=utf-8');

        $arrayResponse    = $this->Backend->getAllMovieData();  

        echo json_encode($arrayResponse);
    }
}