<?php
namespace App\Controllers; 

class User extends BaseController{
 
    public function register(){
        if ($this->session->has('user_sesssion')) {
            return redirect()->to(base_url('/dashboard'));
        }
        return view('admin/register');
    }

    public function login(){
        if ($this->session->has('user_sesssion')) {
            return redirect()->to(base_url('/dashboard'));
        }
        return view('admin/login');
    }

    public function logout(){
        if ($this->session->has('user_sesssion')) {
            $this->session->destroy();
            header("Location: /");
            exit();
        }
        return view('admin/login');
    }

    public function dashboard(){
        if ($this->session->has('user_sesssion')) {
            $data = $this->Backend->getDashboardData();
            if ($data['session']['user_role'] == 'user') {
                // return view('admin/movie/list',$data);
                return redirect()->to(base_url('/movie/list'));
            }else{
                return view('admin/dashboard',$data);
            }
        }else{
            return redirect()->to(base_url());
        }
    }

    // User View
    public function list(){
        if ($this->session->has('user_sesssion')) {
            $data['session'] = $this->session->get('user_sesssion');
            $data['userList'] = $this->Backend->getUserList();

            return view('admin/user/list',$data);
        }else{
            return redirect()->to(base_url());
        }
    }

    public function add_edit($user_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session'] = $this->session->get('user_sesssion');
            if ($data['session']['user_role'] != 'superadmin') {
                // return view('admin/movie/list',$data);
                return redirect()->to(base_url('/movie/list'));
            }else{

                if($user_id!=''){
                    $data['userData'] = $this->Backend->getUserData($user_id);
                }else{
                    $data['userData'] = [];
                }

                return view('admin/user/add_edit',$data);
            }
        }else{
            return redirect()->to(base_url());
        }
    }
}


