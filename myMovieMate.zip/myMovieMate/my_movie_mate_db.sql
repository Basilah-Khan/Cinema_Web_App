-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 03, 2024 at 09:41 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `my_movie_mate_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `movie`
--

CREATE TABLE `movie` (
  `id` int(11) NOT NULL,
  `pub_date` date NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `img` varchar(255) NOT NULL,
  `runtime` time NOT NULL,
  `rating` float NOT NULL DEFAULT 1,
  `link` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `movie`
--

INSERT INTO `movie` (`id`, `pub_date`, `title`, `description`, `img`, `runtime`, `rating`, `link`) VALUES
(1, '2022-02-09', 'Star Light Adventure', 'Barbie, a space Princess, sees her world rapidly change when the stars in the sky begin to fade away. On her fascinating voyage to a new planet, she joins forces with a special rescue team.', '001.jpg', '09:16:14', 4.5, '001.mp4'),
(2, '2024-02-27', 'Behne Do', 'Behne Do Song Lyrics: This song is sung, written and composed by Vismay Patel. \"Behne Do\" song is about people who really want to chase their dreams. This song is released on Vismay\'s Official Youtube channel.\nBehne Do Song Details:\nSong: Behne Do\nSinger: Vismay Patel\nMusic: Vismay Patel\nLyrics: Vismay Patel', '64873.jpg', '13:10:00', 3, '64873.mp4');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `role` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `role`, `name`, `email`, `password`) VALUES
(1, 'superadmin', 'Super admin', 'super@gmail.com', 'c42aad84a73411b78de30dc2138333216aa71d5887dbe556fbfd43100e9d99d6bd452a6ed57f1b440b3477b3191dd7eb4e0522b44eeafeca4fb059d1cea79ace536280649f16d3041e837b40824e514d77e013a5d8'),
(2, 'user', 'user', 'user@gmail.com', '069ae350a8a30d966a5c073ad8b6f9287fa2353221ec34a03a89dfc1cfae2a587d072e4b0975d3808f6746a90986b61ca1230d7de31ecef020d67edd89e84c8ee9864b7530a4cb632c634499a03304fa1a1035366b'),
(3, 'admin', 'admin', 'admin@gmail.com', '012cacfebfb246e971ffdcad421e1a70248b11d3efc9f5bfcf06ff770e809abebf6087a6495c9d60f931ed273fa239c37e7adc86f3199ee4140761f56ad9ef5122ce92d91c894fbcdb55db00bae637f59203790ed7');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `movie`
--
ALTER TABLE `movie`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `movie`
--
ALTER TABLE `movie`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
